package retryanalyzer;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryListener implements  IRetryAnalyzer{

	public boolean retry(ITestResult result) {
		int count=1;
		if(count<2)
		{
			count++;

			return true;
		}
		else {
		return false;
	}

}
	}
